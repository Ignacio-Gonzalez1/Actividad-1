﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto4
{
    /*  Actividad 4: Sistema de Opinión sobre un Producto
        Problema:
        Se quiere crear un formulario de opinión para un producto.
        Requisitos:
        ● Un Label debe indicar: "Escribe tu opinión".
        ● Incluir un TextBox grande (multilínea) donde el usuario escriba su comentario.
        ● Dos RadioButton deben permitir seleccionar sí recomiendan el producto: "Sí" o "No".
        ● Al hacer clic en el botón "Enviar", se debe mostrar un Label con el mensaje: "Opinión
        recibida: [texto] – Recomendación: [Sí/No]";.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Multiline = true;
            textBox1.ScrollBars = ScrollBars.Vertical;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label3.Text = "";
            if (radioButton1.Checked == true)
            {
                label3.Text = "Opinión recibida: " + textBox1.Text + " Recomendación: " + radioButton1.Text;
            }
            if (radioButton2.Checked == true)
            {
                label3.Text = "Opinión recibida: " + textBox1.Text + " Recomendación: " + radioButton2.Text;
            }
        }
    }
}
