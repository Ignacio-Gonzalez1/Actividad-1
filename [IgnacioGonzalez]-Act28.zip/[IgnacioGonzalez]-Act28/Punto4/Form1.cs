﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto4
{
    /*  Temporizador de Clics (Investigación: Timer)
        Investigación: Explicar el componente Timer (propiedades Interval, Enabled y evento Tick) con un breve ejemplo explicativo.
        Consigna: Crear un mini-juego donde un Button cuente cuántos clics realiza el usuario en 10 segundos. 
        Al finalizar el tiempo mediante el Timer, deshabilitar el botón (Enabled = false) 
        y mostrar el puntaje acumulado en un MessageBox.Show.

    */
    public partial class Form1 : Form
    {
        private int numeroTotal;
        public Form1()
        {
            InitializeComponent();
            timer1.Interval = 10000;
            numeroTotal = 0;
            timer1.Start();
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            button1.Enabled = false;
            MessageBox.Show("La cantidad de clicks que dio en el button fue: "+ numeroTotal);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            numeroTotal++;
        }
    }
}
