﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto3
{
    /*  Gestor de Tareas Simplificado (Investigación: ListBox)
        Investigación: Investigar el control ListBox (propiedad Items, métodos Add() y RemoveAt()). 
        Explicar brevemente su funcionamiento e incluir un ejemplo resuelto.
        Consigna: Armar una interfaz con un TextBox, un Button "Agregar", un Button "Eliminar" y un ListBox. 
        Permitir añadir el texto tipeado a la lista y borrar el elemento que el usuario seleccione.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (!string.IsNullOrWhiteSpace(textBox1.Text))//esto sirve para vereficar si esta vacio, es nulo o si solo hay espacios en blanco 
            {
                listBox1.Items.Add(textBox1.Text);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItems.Count > 0)//ve si hay algo seleccionado
            {
                for (int i = listBox1.SelectedIndices.Count - 1; i >= 0; i--)
                {//esto ayuda a borrar los seleccionados y que no borre los no seleccionados que tengan su mismo nombre
                    int indiceEspecifico = listBox1.SelectedIndices[i];
                    listBox1.Items.RemoveAt(indiceEspecifico);
                }
                /*
                while (listBox1.SelectedItems.Count > 0)//esto no va parar hasta borrar todo lo seleccionado
                {
                    listBox1.Items.Remove(listBox1.SelectedItems[0]);
                }
                //foreach (int indice in listBox1.SelectedIndices)//esto sirve para saber los indeces seleccionados, listBox1.SelectedItems para un solo item
                //{
                //    listBox1.Items.RemoveAt(0);
                //}
                */
            }
        }
    }
}
