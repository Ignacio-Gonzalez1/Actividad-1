﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto5
{
    /*  Visor Dinámico de Imágenes (Investigación: PictureBox)
        Investigación: Investigar la clase PictureBox y sus propiedades ImageLocation y SizeMode.
        Consigna: Cargar en un ComboBox tres opciones. 
        Al cambiar la selección mediante el evento SelectedIndexChanged, 
        mostrar la imagen correspondiente dentro del PictureBox.

    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                pictureBox1.ImageLocation = "https://thumbs.dreamstime.com/b/peque%C3%B1o-gatito-lindo-hermoso-meowing-y-que-sonr%C3%ADe-31496658.jpg";
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            if (comboBox1.SelectedIndex == 1)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEiGgGOw6xs0UD3TZUKJfHOtlqsya8mgLje3JguZqVSw&s=10";
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            if (comboBox1.SelectedIndex==2)
            {
                pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMHPguep7lbD5ADNKgDy4VfYuD1DXSmRVblvvJC4OTkgfwat1EuUZlJOPB&s=10";
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }
    }
}
