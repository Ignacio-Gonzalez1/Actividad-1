﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto2
{
    /*  Disponer 7 objetos de la clase Button con los días de la semana. Fijar en
        los atributos Text de cada botón los días de la semana. Al presionar un
        botón mostrar en un objeto de la clase Label el día seleccionado.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Lunes_Click(object sender, EventArgs e)
        {
            label1.Text = Lunes.Text;
        }

        private void Martes_Click(object sender, EventArgs e)
        {
            label1.Text = Martes.Text;
        }

        private void Miercoles_Click(object sender, EventArgs e)
        {
            label1.Text = Miercoles.Text;

        }

        private void Jueves_Click(object sender, EventArgs e)
        {
            label1.Text = Jueves.Text;

        }

        private void Viernes_Click(object sender, EventArgs e)
        {
            label1.Text = Viernes.Text;

        }

        private void Sabado_Click(object sender, EventArgs e)
        {
            label1.Text = Sabado.Text;

        }

        private void Domingo_Click(object sender, EventArgs e)
        {
            label1.Text = Domingo.Text;

        }
    }
}
