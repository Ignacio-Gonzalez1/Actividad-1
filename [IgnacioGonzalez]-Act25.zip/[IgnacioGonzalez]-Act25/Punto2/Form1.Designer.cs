﻿namespace Punto2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lunes = new System.Windows.Forms.Button();
            this.Martes = new System.Windows.Forms.Button();
            this.Miercoles = new System.Windows.Forms.Button();
            this.Jueves = new System.Windows.Forms.Button();
            this.Viernes = new System.Windows.Forms.Button();
            this.Sabado = new System.Windows.Forms.Button();
            this.Domingo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Lunes
            // 
            this.Lunes.Location = new System.Drawing.Point(100, 90);
            this.Lunes.Name = "Lunes";
            this.Lunes.Size = new System.Drawing.Size(75, 23);
            this.Lunes.TabIndex = 0;
            this.Lunes.Text = "Lunes";
            this.Lunes.UseVisualStyleBackColor = true;
            this.Lunes.Click += new System.EventHandler(this.Lunes_Click);
            // 
            // Martes
            // 
            this.Martes.Location = new System.Drawing.Point(181, 90);
            this.Martes.Name = "Martes";
            this.Martes.Size = new System.Drawing.Size(75, 23);
            this.Martes.TabIndex = 1;
            this.Martes.Text = "Martes";
            this.Martes.UseVisualStyleBackColor = true;
            this.Martes.Click += new System.EventHandler(this.Martes_Click);
            // 
            // Miercoles
            // 
            this.Miercoles.Location = new System.Drawing.Point(262, 90);
            this.Miercoles.Name = "Miercoles";
            this.Miercoles.Size = new System.Drawing.Size(75, 23);
            this.Miercoles.TabIndex = 2;
            this.Miercoles.Text = "Miercoles";
            this.Miercoles.UseVisualStyleBackColor = true;
            this.Miercoles.Click += new System.EventHandler(this.Miercoles_Click);
            // 
            // Jueves
            // 
            this.Jueves.Location = new System.Drawing.Point(343, 90);
            this.Jueves.Name = "Jueves";
            this.Jueves.Size = new System.Drawing.Size(75, 23);
            this.Jueves.TabIndex = 3;
            this.Jueves.Text = "Jueves";
            this.Jueves.UseVisualStyleBackColor = true;
            this.Jueves.Click += new System.EventHandler(this.Jueves_Click);
            // 
            // Viernes
            // 
            this.Viernes.Location = new System.Drawing.Point(424, 90);
            this.Viernes.Name = "Viernes";
            this.Viernes.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Viernes.Size = new System.Drawing.Size(75, 23);
            this.Viernes.TabIndex = 4;
            this.Viernes.Text = "Viernes";
            this.Viernes.UseVisualStyleBackColor = true;
            this.Viernes.Click += new System.EventHandler(this.Viernes_Click);
            // 
            // Sabado
            // 
            this.Sabado.Location = new System.Drawing.Point(505, 90);
            this.Sabado.Name = "Sabado";
            this.Sabado.Size = new System.Drawing.Size(75, 23);
            this.Sabado.TabIndex = 5;
            this.Sabado.Text = "Sabado";
            this.Sabado.UseVisualStyleBackColor = true;
            this.Sabado.Click += new System.EventHandler(this.Sabado_Click);
            // 
            // Domingo
            // 
            this.Domingo.Location = new System.Drawing.Point(586, 90);
            this.Domingo.Name = "Domingo";
            this.Domingo.Size = new System.Drawing.Size(75, 23);
            this.Domingo.TabIndex = 6;
            this.Domingo.Text = "Domingo";
            this.Domingo.UseVisualStyleBackColor = true;
            this.Domingo.Click += new System.EventHandler(this.Domingo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(362, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "El Dia Elegido";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Domingo);
            this.Controls.Add(this.Sabado);
            this.Controls.Add(this.Viernes);
            this.Controls.Add(this.Jueves);
            this.Controls.Add(this.Miercoles);
            this.Controls.Add(this.Martes);
            this.Controls.Add(this.Lunes);
            this.Name = "Form1";
            this.Text = "Poner Dia de la Semana";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Lunes;
        private System.Windows.Forms.Button Martes;
        private System.Windows.Forms.Button Miercoles;
        private System.Windows.Forms.Button Jueves;
        private System.Windows.Forms.Button Viernes;
        private System.Windows.Forms.Button Sabado;
        private System.Windows.Forms.Button Domingo;
        private System.Windows.Forms.Label label1;
    }
}

