﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto8
{
    /*  Consigna: Solicitar usuario y contraseña mediante TextBox (usando UseSystemPasswordChar = true). 
     *  Un CheckBox "Acepto términos" debe habilitar (Enabled = true) el Button "Ingresar".
     *  Si la clave coincide con "admin123", mostrar éxito en una Label; de lo contrario, mostrar advertencia.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox2.UseSystemPasswordChar = true;
            button1.Enabled = false;

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text))
            {
                if (textBox2.Text == "admin123")
                {
                    label3.Text = "Accediste a la cuenta";
                }
                else
                {
                    MessageBox.Show("Esta Incorrecto la Contraseña, ponga la correcta.");
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }
    }
}
