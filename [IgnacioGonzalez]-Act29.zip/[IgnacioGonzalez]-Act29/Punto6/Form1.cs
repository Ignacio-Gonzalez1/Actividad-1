﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto6
{
    /*  Consigna: Disponer tres CheckBox con productos y precios fijos. 
     *  Un Button "Calcular Total" debe evaluar los controles seleccionados (Checked == true), 
     *  sumar sus costos y mostrar el monto final en un Label.
    */
    public partial class Form1 : Form
    {
        private int manzana, cebollin,pancho;
        public Form1()
        {
            InitializeComponent();
            manzana = 2;
            cebollin = 3;
            pancho = 10;
            label2.Text = "0$";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (checkBox1.Checked==true)
            {
                total = total + pancho;
            }
            if (checkBox2.Checked == true)
            {
                total = total + manzana;
            }
            if (checkBox3.Checked == true)
            {
                total = total + cebollin;
            }
            label2.Text= total.ToString()+"$";
        }
    }
}
