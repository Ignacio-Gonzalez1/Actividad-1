﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto7
{
    /*  Consigna: Crear tres NumericUpDown restringidos entre 0 y 255 (Rojo, Verde, Azul). 
     *  Un Button cambiará la propiedad BackColor del Form aplicando Color.FromArgb().

     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            numericUpDown1.Minimum = 0;
            numericUpDown1.Maximum = 255;
            numericUpDown1.Value = 0;
            numericUpDown2.Minimum = 0;
            numericUpDown2.Maximum = 255;
            numericUpDown2.Value = 0;
            numericUpDown3.Minimum = 0;
            numericUpDown3.Maximum = 255;
            numericUpDown3.Value = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numero1, numero2, numero3;
            numero1=(int)numericUpDown1.Value;
            numero2 = (int)numericUpDown2.Value;
            numero3 = (int)numericUpDown3.Value;
            this.BackColor = Color.FromArgb(numero1, numero2, numero3);
        }
    }
}
