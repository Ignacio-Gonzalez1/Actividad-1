﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Punto2
{
    /*  Permitir el ingreso de dos números en controles de tipo TextBox y mediante
        dos controles de tipo RadioButton permitir seleccionar si queremos sumarlos o
        restarlos. Al presionar un botón mostrar en el título del Form el resultado de la
        operación.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            int x, y, r;
            x = 0;
            y = 0;
            r = 0;
            Text = "";
            if (radioButton1.Checked == true)
            {
                Text = "";
                x = int.Parse(textBox1.Text);
                y = int.Parse(textBox2.Text);
                r = x + y;
                Text = r.ToString();
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            int x, y, r;
            x = 0;
            y = 0;
            r = 0;
            Text = "";
            if (radioButton2.Checked == true)
            {
                Text = "";
                x = int.Parse(textBox1.Text);
                y = int.Parse(textBox2.Text);
                r = x - y;
                Text = r.ToString();
            }
        }
    }
}
