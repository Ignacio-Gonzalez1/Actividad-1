﻿namespace Punto3
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(108, 122);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Paraguay",
            "España",
            "Francia",
            "Argentina",
            "Peru",
            "Alemania",
            "Polonia",
            "Austria",
            "Suiza",
            "Italia",
            "Brasil",
            "Estados Unidos",
            "Mexico",
            "Colombia",
            "Ecuador",
            "Guayana Francesa",
            "Surinam",
            "Guyuna",
            "Bolivia",
            "Uruguay",
            "Inglaterra",
            "Grecia",
            "Lituania",
            "Estonia",
            "Letonia",
            "Rumania",
            "Luxenburgo",
            "Paises Bajos",
            "Belgica",
            "Monaco",
            "Vaticano",
            "Montenegro",
            "San Marino",
            "Andorra",
            "Eslovaquia",
            "Republica Checa",
            "Gales",
            "Irlanda",
            "Irlanda del Norte",
            "Noruega",
            "Suecia",
            "Finlandia",
            "Rusia",
            "Islandia",
            "Dinamarca",
            "Bosnia",
            "Ucrania",
            "Bielorusia",
            "Serbia",
            "Macedonia del Norte",
            "Kosovo",
            "Croacia",
            "Eslovenia",
            "Israel",
            "Hungria",
            "Bulgaria",
            "Liechtenstein",
            "Turquia",
            "Marruecos",
            "Egitpo",
            "Chad",
            "Niger",
            "Nigeria",
            "Costa De Marfil",
            "Cabo Verde",
            "Republica del Congo",
            "Curazao",
            "Sudafrica",
            "Tunez",
            "Guinea Ecuatorial",
            "Guinea Bissau",
            "Arabia Saudita",
            "Catar",
            "Iran",
            "Irak",
            "India",
            "Mongolia",
            "China",
            "Japon",
            "Pakistan",
            "Uzbekistan",
            "Emiratos Arabes Unidos",
            "Vietnam",
            "Nepal",
            "Tailandia",
            "Libano",
            "Jordania",
            "Oman",
            "Etiopia",
            "Honduras",
            "Costa Rica",
            "Republica Dominicana",
            "Puerto Rico",
            "Cuba",
            "Nicaragua",
            "El Salvador",
            "Guatemala",
            "Jamaica",
            "Canada",
            "Panama",
            "Belice",
            "Islas Caiman",
            "Afganistán",
            "Siria",
            "Kuwai",
            "Yemen",
            "Geogia",
            "Azerbaijan",
            "Kirguistán",
            "Kiribati",
            "Corea del Sur",
            "Corea del Norte",
            "Taiwan",
            "Filipinas",
            "Laos",
            "Camboya",
            "Bangladesh",
            "Uganda",
            "Angola",
            "Birmania",
            "Malasia",
            "Singapur",
            "Indonesia",
            "Papua Nueva Guinea",
            "Islas Fiyi",
            "Australia",
            "Nueva Zelanda",
            "Samoa",
            "Islas Cook",
            "Islas Salomon",
            "Tayikistán",
            "Turkmenistan",
            "Kazajistán",
            "Chipre",
            "Sambia",
            "Burkina Faso",
            "Armenia",
            "Malta",
            "Albania",
            "Argelia",
            "Mauritania",
            "Sahara Occidental",
            "Senegal",
            "Mozambique",
            "Eritea",
            "Togo",
            "Benin",
            "Gambia",
            "Gabon",
            "Liberia",
            "Ghana",
            "Nambia",
            "Zimbague",
            "Namibia",
            "Botzuana",
            "Esuatini",
            "Lesoto",
            "Tanzania",
            "Madagascar",
            "Trinidad y Tobago",
            "Ruanda",
            "Somalia",
            "Yibuti",
            "Sudan",
            "Kenia",
            "Barein",
            "Antigua Barbuda",
            "Camerun",
            "Groenlandia",
            "Hawai",
            "Ex Pais(Venezuela)"});
            this.comboBox1.Location = new System.Drawing.Point(353, 122);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(261, 255);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
    }
}

